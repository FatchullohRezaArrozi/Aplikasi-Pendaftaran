<?php
// Halaman ini telah digabungkan ke admin_mahasiswa.php / mahasiswa.php
// Redirect ke halaman baru dengan tab pengajuan aktif
header('Location: mahasiswa.php?tab=pengajuan');
exit;